# FUK Studio v2 — IA locale et montage bêta

## Ce que contient cette version
- Moteur WebLLM dans le navigateur : l'inférence du modèle est locale après téléchargement.
- Pipeline coordonné : réalisateur → scénariste → storyboard → contrôle qualité. Chaque étape reçoit le résultat précédent.
- Montage bêta : import de photos et clips, texte incrusté et tentative d'export vidéo WebM via les capacités natives du navigateur.

## Limites à connaître
- Ce n'est pas un modèle entraîné de zéro. Le code WebLLM et les poids du modèle doivent être téléchargés depuis Internet au premier lancement.
- Aucune API d'inférence IA externe n'est appelée par le code de génération.
- L'export WebM dépend de `MediaRecorder`, `canvas.captureStream`, des codecs et de la mémoire disponibles sur l'appareil. Il n'a pas été testé sur tous les téléphones Android.
- Le montage bêta n'ajoute pas encore de piste audio, de voix off, de musique, de sous-titres automatiques ni d'export MP4.
- La génération IA nécessite un navigateur compatible WebGPU. Si WebGPU n'est pas disponible, le montage vidéo peut rester utilisable séparément, selon les API du navigateur.

## Installation
1. Télécharge `FUK-Studio-v2-local.html`.
2. Pour remplacer l'ancienne page d'un site, renomme ce fichier `index.html` et téléverse-le dans le dossier racine du site.
3. Publie le site en HTTPS. Ouvre-le dans Chrome Android à jour.
4. Commence par tester le montage avec deux petites photos. Pour le moteur IA, choisis d'abord le modèle le plus léger et utilise le Wi-Fi : le premier téléchargement peut être volumineux.
5. Si le modèle échoue, note le message exact affiché dans la zone « Moteur IA local ». Ne considère pas l'IA comme opérationnelle tant qu'une génération de test n'a pas réussi.

Le fichier est une version de développement : les fonctions non vérifiées sur ton téléphone sont explicitement signalées comme bêta.
